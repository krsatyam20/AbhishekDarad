# single line comment
'''
Multiple line comment
comment: comment is a short description of any object which is writen by user
for refernce purpose
commented line is ignored by python compiler.

Run any program to press "F5" key 
'''

print("hello student")

'''
variable: variable is a temp memory location where we can store our value/data 


'''

a=10 #here a is an variable and 10 is an value

print(a)

a=20
print(type(a))

# add two value in python

a=20
b=30

c= a+b

#concinate string and varible 
print("Add value of", a ,"and ",b ,"=",c)

#Get Input from user throg keyboard

x=int(input("Please enter the value of x="))

y=int(input("Please enter the value of y="))


z=x+y

print("Add value of", x ,"and ",y ,"=",z)



















